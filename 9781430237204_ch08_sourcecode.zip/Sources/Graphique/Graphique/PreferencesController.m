//
// From the book Beginning Mac OS X Lion Apps Development
// Michael Privat and Rob Warner
// Published by Apress, 2011
// Source released under the Eclipse Public License
// http://www.eclipse.org/legal/epl-v10.html
// 
// Contact information:
// Michael: @michaelprivat -- http://michaelprivat.com -- mprivat@mac.com
// Rob: @hoop33 -- http://grailbox.com -- rwarner@grailbox.com
//

#import "PreferencesController.h"
#import "GraphiqueAppDelegate.h"

@implementation PreferencesController

@synthesize initialViewIsGraph;
@synthesize showStatusItem;

- (id)init
{
  self = [super initWithWindowNibName:@"PreferencesController"];
  return self;
}

- (void)windowDidLoad
{
  [super windowDidLoad];
  
  // Get the user defaults
  NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
  
  // Set the checkbox to reflect the user defaults
  [initialViewIsGraph setState:[userDefaults boolForKey:@"InitialViewIsGraph"]];
  
  // Set the status item checkbox
  [showStatusItem setState:[userDefaults boolForKey:@"ShowStatusItem"]];
}

- (IBAction)changeInitialView:(id)sender
{
  // Get the user defaults
  NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
  
  // Set the user defaults value for the initial view
  [userDefaults setBool:[initialViewIsGraph state] forKey:@"InitialViewIsGraph"];
}

- (IBAction)changeStatusItem:(id)sender
{
  // Get the user defaults
  NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
  
  // Set the user defaults for the status item
  [userDefaults setBool:[showStatusItem state] forKey:@"ShowStatusItem"];
  
  // Notify the application delegate that the preference for the status item changed
  [(GraphiqueAppDelegate *)[[NSApplication sharedApplication] delegate] updateStatusItemState];
}

@end
