//
// From the book Beginning Mac OS X Lion Apps Development
// Michael Privat and Rob Warner
// Published by Apress, 2011
// Source released under the Eclipse Public License
// http://www.eclipse.org/legal/epl-v10.html
// 
// Contact information:
// Michael: @michaelprivat -- http://michaelprivat.com -- mprivat@mac.com
// Rob: @hoop33 -- http://grailbox.com -- rwarner@grailbox.com
//

#import "GraphiqueStatusItemMenuDelegate.h"
#import "GroupItem.h"
#import "Equation.h"
#import "GraphiqueAppDelegate.h"

#define MAX_ITEMS 10

@implementation GraphiqueStatusItemMenuDelegate

@synthesize rootItem;

- (id)initWithRootItem:(GroupItem *)rootItem_
{
  self = [super init];
  if (self != nil)
  {
    self.rootItem = rootItem_;
  }
  return self;
}

- (void)menuNeedsUpdate:(NSMenu *)menu
{
  // Remove all the menu items to rebuild from scratch
  [menu removeAllItems];
  
  // Keep track of how many menu items we've added so we know when we've reached the limit
  int numItems = 0;
  
  // Loop backwards through the date items
  for (NSInteger i = [rootItem numberOfChildren] - 1; i >= 0 && numItems < MAX_ITEMS; i--)
  {
    // For each date item, loop backward through the equations
    GroupItem *dateItem = [rootItem childAtIndex:i];
    for (NSInteger j = [dateItem numberOfChildren] - 1; j >= 0 && numItems < MAX_ITEMS; j--)
    {
      // For each equation, add a menu item with the equation as the menu title
      GroupItem *equationItem = [dateItem childAtIndex:j];
      [[menu addItemWithTitle:[equationItem text] action:@selector(statusMenuItemSelected:) keyEquivalent:@""] setTarget:self];
      
      // Increment the counter
      ++numItems;
    }
  }
}

- (void)statusMenuItemSelected:(id)sender
{
  // Get the selected menu item
  NSMenuItem *item = (NSMenuItem *)sender;
  
  // Graph the equation
  GraphiqueAppDelegate *delegate = NSApplication.sharedApplication.delegate;
  [delegate showEquationFromString:item.title];
  
  // Bring Graphique to the front
  [NSApp activateIgnoringOtherApps:YES];
}

@end
