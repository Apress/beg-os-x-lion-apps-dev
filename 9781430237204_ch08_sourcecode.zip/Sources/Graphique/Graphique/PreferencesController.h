//
// From the book Beginning Mac OS X Lion Apps Development
// Michael Privat and Rob Warner
// Published by Apress, 2011
// Source released under the Eclipse Public License
// http://www.eclipse.org/legal/epl-v10.html
// 
// Contact information:
// Michael: @michaelprivat -- http://michaelprivat.com -- mprivat@mac.com
// Rob: @hoop33 -- http://grailbox.com -- rwarner@grailbox.com
//

#import <Cocoa/Cocoa.h>

@interface PreferencesController : NSWindowController
{
  NSButton *initialViewIsGraph;
  NSButton *showStatusItem;
}

@property (nonatomic, retain) IBOutlet NSButton *initialViewIsGraph;
@property (nonatomic, retain) IBOutlet NSButton *showStatusItem;

- (IBAction)changeInitialView:(id)sender;
- (IBAction)changeStatusItem:(id)sender;

@end
