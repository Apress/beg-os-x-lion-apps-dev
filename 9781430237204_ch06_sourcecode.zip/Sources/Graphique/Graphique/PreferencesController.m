//
// From the book Beginning Mac OS X Lion Apps Development
// Michael Privat and Rob Warner
// Published by Apress, 2011
// Source released under the Eclipse Public License
// http://www.eclipse.org/legal/epl-v10.html
// 
// Contact information:
// Michael: @michaelprivat -- http://michaelprivat.com -- mprivat@mac.com
// Rob: @hoop33 -- http://grailbox.com -- rwarner@grailbox.com
//

#import "PreferencesController.h"

@implementation PreferencesController

@synthesize initialViewIsGraph;

- (id)init
{
  self = [super initWithWindowNibName:@"PreferencesController"];
  return self;
}

- (void)windowDidLoad
{
  [super windowDidLoad];
  
  // Get the user defaults
  NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
  
  // Set the checkbox to reflect the user defaults
  [initialViewIsGraph setState:[userDefaults boolForKey:@"InitialViewIsGraph"]];
}

- (IBAction)changeInitialView:(id)sender
{
  // Get the user defaults
  NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
  
  // Set the user defaults value for the initial view
  [userDefaults setBool:[initialViewIsGraph state] forKey:@"InitialViewIsGraph"];
}

@end
