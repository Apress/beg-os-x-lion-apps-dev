//
// From the book Beginning Mac OS X Lion Apps Development
// Michael Privat and Rob Warner
// Published by Apress, 2011
// Source released under the Eclipse Public License
// http://www.eclipse.org/legal/epl-v10.html
// 
// Contact information:
// Michael: @michaelprivat -- http://michaelprivat.com -- mprivat@mac.com
// Rob: @hoop33 -- http://grailbox.com -- rwarner@grailbox.com
//


#import "GraphiqueAppDelegate.h"
#import "EquationEntryViewController.h"
#import "GraphTableViewController.h"
#import "RecentlyUsedEquationsViewController.h"
#import "GraphView.h"
#import "PreferencesController.h"

@implementation GraphiqueAppDelegate

@synthesize window = _window;
@synthesize horizontalSplitView;
@synthesize verticalSplitView;
@synthesize equationEntryViewController;
@synthesize graphTableViewController;
@synthesize recentlyUsedEquationsViewController;
@synthesize preferencesController;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
  equationEntryViewController = [[EquationEntryViewController alloc] initWithNibName:@"EquationEntryViewController" bundle:nil];
  [self.verticalSplitView replaceSubview:[[self.verticalSplitView subviews] objectAtIndex:1] with:equationEntryViewController.view];
  
  graphTableViewController = [[GraphTableViewController alloc] initWithNibName:@"GraphTableViewController" bundle:nil];
  [self.horizontalSplitView replaceSubview:[[self.horizontalSplitView subviews] objectAtIndex:1] with:[graphTableViewController view]];
    
  recentlyUsedEquationsViewController = [[RecentlyUsedEquationsViewController alloc] initWithNibName:@"RecentlyUsedEquationsViewController" bundle:nil];
  recentlyUsedEquationsViewController.managedObjectContext = self.managedObjectContext;
  [self.verticalSplitView replaceSubview:[[self.verticalSplitView subviews] objectAtIndex:0] with:[recentlyUsedEquationsViewController view]];
  self.verticalSplitView.delegate = recentlyUsedEquationsViewController;
  
  [[NSColorPanel sharedColorPanel] setTarget:self];
  [[NSColorPanel sharedColorPanel] setAction:@selector(changeGraphLineColor:)];
}

+ (void)initialize
{
  // Get the user defaults
  NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
  
  // Set the font to a reasonable choice and convert to an NSData object
  NSFont *equationFont = [NSFont systemFontOfSize:18.0];
  NSData *fontData = [NSArchiver archivedDataWithRootObject:equationFont];
  
  // Set the color to a reasonable choice and convert to an NSData object
  NSColor *lineColor = [NSColor blackColor];
  NSData *colorData = [NSArchiver archivedDataWithRootObject:lineColor];
  
  // Set the font and color in the defaults
  NSDictionary *appDefaults = [NSDictionary dictionaryWithObjectsAndKeys:fontData, @"equationFont", colorData, @"lineColor", nil];
  [userDefaults registerDefaults:appDefaults];
   
  // Change the action for the Font Panel so that the text field doesn't swallow the changes
  [[NSFontManager sharedFontManager] setAction:@selector(changeEquationFont:)];
  
  // Set the color panel to show only Crayons mode
  [NSColorPanel setPickerMask:NSColorPanelCrayonModeMask];
}

- (void)changeEquationFont:(id)sender
{
  // Get the user defaults
  NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
  
  // Get the user's font selection and convert from NSData to NSFont
  NSData *fontData = [userDefaults dataForKey:@"equationFont"];
  NSFont *equationFont = (NSFont *)[NSUnarchiver unarchiveObjectWithData:fontData];
  
  // Convert the font to the new selection
  NSFont *newFont = [sender convertFont:equationFont];
  
  // Convert the new font into an NSData object and set it back into the user defaults
  fontData = [NSArchiver archivedDataWithRootObject:newFont];
  [userDefaults setObject:fontData forKey:@"equationFont"];
  
  // Tell the equation entry field to update to the new font
  [self.equationEntryViewController controlTextDidChange:nil];
}

- (void)applicationDidBecomeActive:(NSNotification *)aNotification 
{
}

- (void)applicationDidResignActive:(NSNotification *)aNotification
{
}

- (void)changeGraphLineColor:(id)sender
{
  // Set the selected color in the user defaults
  NSData *colorData = [NSArchiver archivedDataWithRootObject:[(NSColorPanel *)sender color]];
  [[NSUserDefaults standardUserDefaults] setObject:colorData forKey:@"lineColor"];
  
  // Tell the graph to redraw itself
  [self.graphTableViewController.graphView setNeedsDisplay:YES];
}

- (IBAction)showPreferencesPanel:(id)sender
{
  // Create the preferences panel if we haven't already
  if (preferencesController == nil)
  {
    preferencesController = [[PreferencesController alloc] init];
  }
  
  // Show the panel
  [preferencesController showWindow:self];
}

- (NSManagedObjectModel *)managedObjectModel {    
  if (managedObjectModel_ != nil) {
    return managedObjectModel_;
  }
  managedObjectModel_ = [NSManagedObjectModel mergedModelFromBundles:nil];
  return managedObjectModel_;
}

- (NSPersistentStoreCoordinator *)persistentStoreCoordinator {    
  if (persistentStoreCoordinator_ != nil) {
    return persistentStoreCoordinator_;
  }
  
  NSString* dir = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
  NSURL *storeURL = [NSURL fileURLWithPath: [dir stringByAppendingPathComponent: @"Graphique.sqlite"]];
  
  NSError *error = nil;
  persistentStoreCoordinator_ = [[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel:[self managedObjectModel]];
  if (![persistentStoreCoordinator_ addPersistentStoreWithType:NSSQLiteStoreType configuration:nil URL:storeURL options:nil error:&error]) {
    NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
    abort();
  }    
  
  return persistentStoreCoordinator_;
}

- (NSManagedObjectContext *)managedObjectContext {    
  if (managedObjectContext_ != nil) {
    return managedObjectContext_;
  }
  
  NSPersistentStoreCoordinator *coordinator = [self persistentStoreCoordinator];
  if (coordinator != nil) {
    managedObjectContext_ = [[NSManagedObjectContext alloc] init];
    [managedObjectContext_ setPersistentStoreCoordinator:coordinator];
  }
  return managedObjectContext_;
}

@end
