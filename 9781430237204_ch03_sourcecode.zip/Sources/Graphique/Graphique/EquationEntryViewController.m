//
// From the book Beginning Mac OS X Lion Apps Development
// Michael Privat and Rob Warner
// Published by Apress, 2011
// Source released under the Eclipse Public License
// http://www.eclipse.org/legal/epl-v10.html
// 
// Contact information:
// Michael: @michaelprivat -- http://michaelprivat.com -- mprivat@mac.com
// Rob: @hoop33 -- http://grailbox.com -- rwarner@grailbox.com
//

#import "EquationEntryViewController.h"
#import "GraphiqueAppDelegate.h"
#import "Equation.h"
#import "GraphTableViewController.h"

@implementation EquationEntryViewController

@synthesize textField;
@synthesize feedback;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
  self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
  if (self) {
    // Initialization code here.
  }
  
  return self;
}

- (void)alertDidEnd:(NSAlert *)alert returnCode:(NSInteger)returnCode
        contextInfo:(void *)contextInfo 
{
  
}

- (IBAction)equationEntered:(id)sender
{
  GraphiqueAppDelegate *delegate = NSApplication.sharedApplication.delegate;
  
  Equation *equation = [[Equation alloc] initWithString:[self.textField stringValue]];
  NSError *error = nil;
  if(![equation validate:&error]) 
  {
    // Validation failed, display the error
    NSAlert *alert = [[NSAlert alloc] init];
    [alert addButtonWithTitle:@"OK"];
    [alert setMessageText:@"Something went wrong. "];
    [alert setInformativeText:[NSString stringWithFormat:@"Error %d: %@", [error code],[error localizedDescription]]];
    [alert setAlertStyle:NSWarningAlertStyle];
    
    [alert beginSheetModalForWindow:delegate.window modalDelegate:self didEndSelector:@selector(alertDidEnd:returnCode:contextInfo:) contextInfo:nil];
  }
  else 
  {
    [delegate.graphTableViewController draw:equation];
  }
}

- (void)controlTextDidChange:(NSNotification *)notification 
{
  Equation *equation = [[Equation alloc] initWithString: [self.textField stringValue]];
  
  NSError *error = nil;
  if(![equation validate:&error]) 
  {
    // Validation failed, display the error
    [feedback setStringValue:[NSString stringWithFormat:@"Error %d: %@", [error code],[error localizedDescription]]];
  }
  else 
  {
    [feedback setStringValue:@""];
  }
}

@end
