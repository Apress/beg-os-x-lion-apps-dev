//
// From the book Beginning Mac OS X Lion Apps Development
// Michael Privat and Rob Warner
// Published by Apress, 2011
// Source released under the Eclipse Public License
// http://www.eclipse.org/legal/epl-v10.html
// 
// Contact information:
// Michael: @michaelprivat -- http://michaelprivat.com -- mprivat@mac.com
// Rob: @hoop33 -- http://grailbox.com -- rwarner@grailbox.com
//

#import "Equation.h"

@interface Equation ()
- (BOOL)produceError:(NSError**)error withCode:(NSInteger)code andMessage:(NSString*)message;
@end

@implementation Equation

@synthesize text;

- (id)initWithString:(NSString *)string
{
  self = [super init];
  if (self) {
    self.text = string;
  }
  return self;
}

- (float)evaluateForX:(float)x 
{
  NSTask *task = [[NSTask alloc] init];
  [task setLaunchPath: @"/usr/bin/awk"];
  
  NSArray *arguments = [NSArray arrayWithObjects: [NSString stringWithFormat:@"BEGIN { x=%f ; print %@ ; }", x, self.text], nil];
  [task setArguments:arguments];
  
  NSPipe *pipe = [NSPipe pipe];
  [task setStandardOutput:pipe];
  
  NSFileHandle *file = [pipe fileHandleForReading];
  [task launch];
  
  NSData *data = [file readDataToEndOfFile];
  
  NSString *string = [[NSString alloc] initWithData:data encoding: NSUTF8StringEncoding];
  float value = [string floatValue];
  
  return value;
}

- (NSString *)description
{
  return [NSString stringWithFormat:@"Equation [%@]", self.text];
}

- (BOOL)validate:(NSError **)error 
{
  // Validation rules
  // 1. Only digits, letters '.', 'x', '(', ')', '+' , '-' , '*', '/', '^', ' ' allowed
  // 2. There should be the same amount of closing and opening parentheses
  // 3. no two consecutive operators
  
  // Counters for '(' and ')'
  NSUInteger open = 0;
  NSUInteger close = 0;
  
  NSString *allowedCharacters = @"x()+-*/^0123456789. ";
  
  NSCharacterSet *cs = [NSCharacterSet characterSetWithCharactersInString:allowedCharacters];
  NSCharacterSet *operators = [NSCharacterSet characterSetWithCharactersInString:@"+-/*^"];
  
  unichar previous = 0;
  
  for(NSUInteger i=0; i<text.length; i++) 
  {
    unichar c = [text characterAtIndex:i];
    if(![cs characterIsMember:c]) 
    {
      // Invalid character
      return [self produceError:error withCode:100 andMessage:[NSString stringWithFormat:@"Invalid character typed. Only '%@' are allowed", allowedCharacters]];
    }
    else if(c == '(') open++;
    else if(c == ')') close++;
    
    if([operators characterIsMember:c] && [operators characterIsMember:previous]) 
    {
      // Two consecutive operators
      return [self produceError:error withCode:101 andMessage:@"Consecutive operators are not allowed"];  
    }
    
    if(c != ' ') previous = c;
  }
  
  if(open < close) 
  {
    // Invalid character
    return [self produceError:error withCode:103 andMessage:@"Too many closed parentheses"];
  }
  else if(open > close) 
  {
    // Invalid character
    return [self produceError:error withCode:102 andMessage:@"Too many open parentheses"];
  }
  
  return YES;
}

- (BOOL)produceError:(NSError**)error withCode:(NSInteger)code andMessage:(NSString*)message 
{
  if (error != NULL) 
  {
    NSMutableDictionary *errorDetail = [NSMutableDictionary dictionary];
    [errorDetail setValue:message forKey:NSLocalizedDescriptionKey];
    *error = [NSError errorWithDomain:@"Graphique" code:code userInfo:errorDetail];
  }
  return NO;
}

@end
