//
// From the book Beginning Mac OS X Lion Apps Development
// Michael Privat and Rob Warner
// Published by Apress, 2011
// Source released under the Eclipse Public License
// http://www.eclipse.org/legal/epl-v10.html
// 
// Contact information:
// Michael: @michaelprivat -- http://michaelprivat.com -- mprivat@mac.com
// Rob: @hoop33 -- http://grailbox.com -- rwarner@grailbox.com
//

#import "RecentlyUsedEquationsViewController.h"
#import "GroupItem.h"
#import "EquationItem.h"

@implementation RecentlyUsedEquationsViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil 
{
  self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
  if (self) 
  {
    rootItem = [[GroupItem alloc] init];
    
    for (int i = 0; i < 4; i++) 
    {
      GroupItem *temp = [[GroupItem alloc] init];
      temp.name = [NSString stringWithFormat:@"Group %d", i + 1];
      
      for (int j = 0; j < 5; j++) 
      {
        EquationItem *item = [[EquationItem alloc] init];
        [temp addChild:item];
      }
      [rootItem addChild:temp];
    }
  }  
  return self;
}

- (NSInteger)outlineView:(NSOutlineView *)outlineView numberOfChildrenOfItem:(id)item 
{
  return (item == nil) ? [rootItem numberOfChildren] : [item numberOfChildren];
}

- (BOOL)outlineView:(NSOutlineView *)outlineView isItemExpandable:(id)item 
{
  return (item == nil) ? ([rootItem numberOfChildren] > 0) : ([item numberOfChildren] > 0);
}

- (id)outlineView:(NSOutlineView *)outlineView child:(NSInteger)index ofItem:(id)item 
{
  if (item == nil) 
  {
    return [rootItem childAtIndex:index];
  } 
  else 
  {
    return [(GroupItem *)item childAtIndex:index];
  }
}

- (id)outlineView:(NSOutlineView *)outlineView objectValueForTableColumn:(NSTableColumn *)tableColumn byItem:(id)item 
{
  return (item == nil) ? @"" : [item text];
}

@end
