//
// From the book Beginning Mac OS X Lion Apps Development
// Michael Privat and Rob Warner
// Published by Apress, 2011
// Source released under the Eclipse Public License
// http://www.eclipse.org/legal/epl-v10.html
// 
// Contact information:
// Michael: @michaelprivat -- http://michaelprivat.com -- mprivat@mac.com
// Rob: @hoop33 -- http://grailbox.com -- rwarner@grailbox.com
//


#import <Cocoa/Cocoa.h>
#import <CoreData/CoreData.h>

@class EquationEntryViewController;
@class GraphTableViewController;
@class RecentlyUsedEquationsViewController;
@class PreferencesController;
@class GraphiqueStatusItemMenuDelegate;

@interface GraphiqueAppDelegate : NSObject <NSApplicationDelegate> {
  @private
  NSManagedObjectContext *managedObjectContext_;
  NSManagedObjectModel *managedObjectModel_;
  NSPersistentStoreCoordinator *persistentStoreCoordinator_;
  NSString *fileName;
  
  NSStatusItem *statusItem;
  NSMenu *statusItemMenu;
  GraphiqueStatusItemMenuDelegate *statusItemMenuDelegate;
}

@property (strong) IBOutlet NSWindow *window;
@property (weak) IBOutlet NSSplitView *horizontalSplitView;
@property (weak) IBOutlet NSSplitView *verticalSplitView;
@property (strong) EquationEntryViewController *equationEntryViewController;
@property (strong) GraphTableViewController *graphTableViewController;
@property (strong) RecentlyUsedEquationsViewController *recentlyUsedEquationsViewController;
@property (strong) PreferencesController *preferencesController;

@property (nonatomic, retain, readonly) NSManagedObjectContext *managedObjectContext;
@property (nonatomic, retain, readonly) NSManagedObjectModel *managedObjectModel;
@property (nonatomic, retain, readonly) NSPersistentStoreCoordinator *persistentStoreCoordinator;

@property (strong) NSStatusItem *statusItem;
@property (strong) NSMenu *statusItemMenu;
@property (strong) GraphiqueStatusItemMenuDelegate *statusItemMenuDelegate;

- (void)changeGraphLineColor:(id)sender;
- (IBAction)showPreferencesPanel:(id)sender;
- (void)loadData:(NSDictionary*)data;
- (void)configureStatusItem;
- (void)showEquationFromString:(NSString *)text;
- (void)updateStatusItemState;

@end
