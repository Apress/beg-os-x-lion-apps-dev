//
// From the book Beginning Mac OS X Lion Apps Development
// Michael Privat and Rob Warner
// Published by Apress, 2011
// Source released under the Eclipse Public License
// http://www.eclipse.org/legal/epl-v10.html
// 
// Contact information:
// Michael: @michaelprivat -- http://michaelprivat.com -- mprivat@mac.com
// Rob: @hoop33 -- http://grailbox.com -- rwarner@grailbox.com
//


#import "GraphiqueAppDelegate.h"
#import "EquationEntryViewController.h"
#import "GraphTableViewController.h"
#import "RecentlyUsedEquationsViewController.h"
#import "GraphView.h"
#import "PreferencesController.h"
#import "GraphiqueStatusItemMenuDelegate.h"

@implementation GraphiqueAppDelegate

@synthesize window = _window;
@synthesize horizontalSplitView;
@synthesize verticalSplitView;
@synthesize equationEntryViewController;
@synthesize graphTableViewController;
@synthesize recentlyUsedEquationsViewController;
@synthesize preferencesController;
@synthesize statusItem, statusItemMenu, statusItemMenuDelegate;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
  self.equationEntryViewController = [[EquationEntryViewController alloc] initWithNibName:@"EquationEntryViewController" bundle:nil];
  [self.verticalSplitView replaceSubview:[[self.verticalSplitView subviews] objectAtIndex:1] with:equationEntryViewController.view];
  
  self.graphTableViewController = [[GraphTableViewController alloc] initWithNibName:@"GraphTableViewController" bundle:nil];
  [self.horizontalSplitView replaceSubview:[[self.horizontalSplitView subviews] objectAtIndex:1] with:graphTableViewController.view];
  
  self.recentlyUsedEquationsViewController = [[RecentlyUsedEquationsViewController alloc] initWithNibName:@"RecentlyUsedEquationsViewController" bundle:nil];
  recentlyUsedEquationsViewController.managedObjectContext = self.managedObjectContext;
  [self.verticalSplitView replaceSubview:[[self.verticalSplitView subviews] objectAtIndex:0] with:recentlyUsedEquationsViewController.view];
  self.verticalSplitView.delegate = recentlyUsedEquationsViewController;
  
  [[NSColorPanel sharedColorPanel] setTarget:self];
  [[NSColorPanel sharedColorPanel] setAction:@selector(changeGraphLineColor:)];
  
  if (fileName != nil)
  {
    NSMutableDictionary *data = [[NSMutableDictionary alloc] initWithContentsOfFile:fileName];
    [self loadData:data];
  }
  
  [self updateStatusItemState];
}

+ (void)initialize
{
  // Get the user defaults
  NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
  
  // Set the font to a reasonable choice and convert to an NSData object
  NSFont *equationFont = [NSFont systemFontOfSize:18.0];
  NSData *fontData = [NSArchiver archivedDataWithRootObject:equationFont];
  
  // Set the color to a reasonable choice and convert to an NSData object
  NSColor *lineColor = [NSColor blackColor];
  NSData *colorData = [NSArchiver archivedDataWithRootObject:lineColor];
  
  // Set the font, color, and status item in the defaults
  NSDictionary *appDefaults = [NSDictionary dictionaryWithObjectsAndKeys:fontData, @"equationFont", colorData, @"lineColor", [NSNumber numberWithBool:YES], @"ShowStatusItem", nil];
  
  [userDefaults registerDefaults:appDefaults];
  
  // Change the action for the Font Panel so that the text field doesn't swallow the changes
  [[NSFontManager sharedFontManager] setAction:@selector(changeEquationFont:)];
  
  // Set the color panel to show only Crayons mode
  [NSColorPanel setPickerMask:NSColorPanelCrayonModeMask];
}

- (void)changeEquationFont:(id)sender
{
  // Get the user defaults
  NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
  
  // Get the user's font selection and convert from NSData to NSFont
  NSData *fontData = [userDefaults dataForKey:@"equationFont"];
  NSFont *equationFont = (NSFont *)[NSUnarchiver unarchiveObjectWithData:fontData];
  
  // Convert the font to the new selection
  NSFont *newFont = [sender convertFont:equationFont];
  
  // Convert the new font into an NSData object and set it back into the user defaults
  fontData = [NSArchiver archivedDataWithRootObject:newFont];
  [userDefaults setObject:fontData forKey:@"equationFont"];
  
  // Tell the equation entry field to update to the new font
  [self.equationEntryViewController controlTextDidChange:nil];
}

- (void)applicationDidBecomeActive:(NSNotification *)aNotification 
{
}

- (void)applicationDidResignActive:(NSNotification *)aNotification
{
}

- (void)changeGraphLineColor:(id)sender
{
  // Set the selected color in the user defaults
  NSData *colorData = [NSArchiver archivedDataWithRootObject:[(NSColorPanel *)sender color]];
  [[NSUserDefaults standardUserDefaults] setObject:colorData forKey:@"lineColor"];
  
  // Tell the graph to redraw itself
  [self.graphTableViewController.graphView setNeedsDisplay:YES];
}

- (IBAction)showPreferencesPanel:(id)sender
{
  // Create the preferences panel if we haven't already
  if (preferencesController == nil)
  {
    preferencesController = [[PreferencesController alloc] init];
  }
  
  // Show the panel
  [preferencesController showWindow:self];
}

- (void)saveDocumentAs:(id)sender
{
  // 1. Grab the current equation
  NSString *text = [self.equationEntryViewController.textField stringValue];
  
  // 2. Open the NSSavePanel
  NSSavePanel *saveDlg = [NSSavePanel savePanel]; 
  [saveDlg setAllowedFileTypes:[NSArray arrayWithObject:@"graphique"]];
  
  // Open the dialog and save if the user selected OK
  NSInteger result = [saveDlg runModal]; 
  if (result == NSOKButton){ 
    // 3. Producing the Graphique file
    NSMutableDictionary *data = [[NSMutableDictionary alloc] init];
    [data setObject:text forKey:@"equation"];
    
    // Create the preview image
    NSBitmapImageRep *imageRep = [graphTableViewController export];
    NSData *img = [imageRep representationUsingType:NSPNGFileType properties:nil];
    [data setObject:img forKey:@"image"];
    
    [data writeToURL:saveDlg.URL atomically:YES];
  }    
}

- (void)openDocument:(id)sender
{
  NSOpenPanel *openDlg = [NSOpenPanel openPanel];
  [openDlg setAllowedFileTypes:[NSArray arrayWithObject:@"graphique"]];
  
  NSInteger result = [openDlg runModal]; 
  if (result == NSOKButton)
  {
    NSMutableDictionary *data = [[NSMutableDictionary alloc] initWithContentsOfURL:openDlg.URL];
    [self loadData:data];
  }      
}

- (BOOL)application:(NSApplication *)theApplication openFile:(NSString *)fileName_ 
{
  fileName = fileName_;
  
  if ([theApplication isRunning]) 
  {
    NSMutableDictionary *data = [[NSMutableDictionary alloc] initWithContentsOfFile:fileName];
    [self loadData:data];
  }
  
  return YES;
}

- (void)loadData:(NSDictionary*)data 
{
  NSString *equationText = [data objectForKey:@"equation"];
  [self showEquationFromString:equationText];
}

- (void)showEquationFromString:(NSString *)text
{
  Equation *equation = [[Equation alloc] initWithString:text];
  
  [self.equationEntryViewController.textField setStringValue:equation.text];
  [self.graphTableViewController draw:equation];    
  
  [self.equationEntryViewController controlTextDidChange:nil];
}

- (NSManagedObjectModel *)managedObjectModel {    
  if (managedObjectModel_ != nil) {
    return managedObjectModel_;
  }
  managedObjectModel_ = [NSManagedObjectModel mergedModelFromBundles:nil];
  return managedObjectModel_;
}

- (NSPersistentStoreCoordinator *)persistentStoreCoordinator {    
  if (persistentStoreCoordinator_ != nil) {
    return persistentStoreCoordinator_;
  }
  
  NSString* dir = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
  NSURL *storeURL = [NSURL fileURLWithPath: [dir stringByAppendingPathComponent: @"Graphique.sqlite"]];
  
  NSError *error = nil;
  persistentStoreCoordinator_ = [[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel:[self managedObjectModel]];
  if (![persistentStoreCoordinator_ addPersistentStoreWithType:NSSQLiteStoreType configuration:nil URL:storeURL options:nil error:&error]) {
    NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
    abort();
  }    
  
  return persistentStoreCoordinator_;
}

- (NSManagedObjectContext *)managedObjectContext {    
  if (managedObjectContext_ != nil) {
    return managedObjectContext_;
  }
  
  NSPersistentStoreCoordinator *coordinator = [self persistentStoreCoordinator];
  if (coordinator != nil) {
    managedObjectContext_ = [[NSManagedObjectContext alloc] init];
    [managedObjectContext_ setPersistentStoreCoordinator:coordinator];
  }
  return managedObjectContext_;
}

- (void)configureStatusItem
{
  // Create the status item
  self.statusItem = [[NSStatusBar systemStatusBar] statusItemWithLength:NSVariableStatusItemLength];
  
  // Set the icon
  [statusItem setImage:[NSImage imageNamed:@"graphique18.png"]];
  
  // Set the item to highlight when clicked
  [statusItem setHighlightMode:YES];
  
  // Create the menu and delegate
  self.statusItemMenu = [[NSMenu alloc] init];
  self.statusItemMenuDelegate = [[GraphiqueStatusItemMenuDelegate alloc] initWithRootItem:self.recentlyUsedEquationsViewController.rootItem];
  [statusItemMenu setDelegate:statusItemMenuDelegate];
  [statusItem setMenu:statusItemMenu];
}

- (void)updateStatusItemState
{
  BOOL showStatusItem = [[NSUserDefaults standardUserDefaults] boolForKey:@"ShowStatusItem"];
  if (showStatusItem && statusItem == nil)
  {
    [self configureStatusItem];
  }
  else if (!showStatusItem && statusItem != nil)
  {
    [[NSStatusBar systemStatusBar] removeStatusItem:statusItem];
    statusItemMenu = nil;
    statusItem = nil;
  }
}

@end
