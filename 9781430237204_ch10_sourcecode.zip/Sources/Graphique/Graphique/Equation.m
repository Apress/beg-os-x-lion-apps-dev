//
// From the book Beginning Mac OS X Lion Apps Development
// Michael Privat and Rob Warner
// Published by Apress, 2011
// Source released under the Eclipse Public License
// http://www.eclipse.org/legal/epl-v10.html
// 
// Contact information:
// Michael: @michaelprivat -- http://michaelprivat.com -- mprivat@mac.com
// Rob: @hoop33 -- http://grailbox.com -- rwarner@grailbox.com
//

#import "Equation.h"
#import "EquationToken.h"
#import "Stack.h"

@interface Equation ()
- (BOOL)produceError:(NSError**)error withCode:(NSInteger)code andMessage:(NSString*)message;
- (void)tokenize;
- (EquationToken *)newTokenFromString:(NSString *)string;
- (NSString *)expand;
@end

static NSArray *OPERATORS;
static NSArray *TRIG_FUNCTIONS;
static NSArray *SYMBOLS;

@implementation Equation

@synthesize text;
@synthesize tokens;

+ (void)initialize
{
  OPERATORS = [NSArray arrayWithObjects:@"+", @"-", @"*", @"/", @"^", nil];
  TRIG_FUNCTIONS = [NSArray arrayWithObjects:@"sin", @"cos", nil];
  SYMBOLS = [NSArray arrayWithObjects:@"pi", @"e", @"\u03c0", nil];
}

- (id)initWithString:(NSString *)string
{
  self = [super init];
  if (self) 
  {
    self.text = string;
    self.tokens = [NSMutableArray array];
    [self tokenize];
  }
  return self;
}

- (float)evaluateForX:(float)x 
{
  NSTask *task = [[NSTask alloc] init];
  [task setLaunchPath: @"/usr/bin/awk"];
  
  NSArray *arguments = [NSArray arrayWithObjects: [NSString stringWithFormat:@"BEGIN { x=%f ; print %@ ; }", x, [self expand]], nil];
  [task setArguments:arguments];
  
  NSPipe *pipe = [NSPipe pipe];
  [task setStandardOutput:pipe];
  
  NSFileHandle *file = [pipe fileHandleForReading];
  [task launch];
  
  NSData *data = [file readDataToEndOfFile];
  
  NSString *string = [[NSString alloc] initWithData:data encoding: NSUTF8StringEncoding];
  float value = [string floatValue];
  
  return value;
}

- (NSString *)description
{
  return [NSString stringWithFormat:@"Equation [%@]", [self expand]];
}

- (BOOL)validate:(NSError**)error
{
  // Validation rules
  // 1. Only digits, operators, variables, parentheses, trigonometric functions, and symbols allowed
  // 2. There should be the same amount of closing and opening parentheses
  // 3. no two consecutive operators
  
  NSString *allowed = @"x, 0-9, (), operators, trig functions, pi, and e";
  EquationToken *previousToken = nil;
  for (EquationToken *token in self.tokens)
  {
    if (!token.valid)
    {
      if (token.type == EquationTokenTypeOpenParen)
      {
        return [self produceError:error withCode:102 andMessage:@"Too many open parentheses"];
      }
      else if (token.type == EquationTokenTypeCloseParen)
      {
        return [self produceError:error withCode:103 andMessage:@"Too many closed parentheses"];
      }
      else
      {
        return [self produceError:error withCode:100 andMessage:[NSString stringWithFormat:@"Invalid character typed. Only %@ are allowed", allowed]];
      }
    }
    if (token.type == EquationTokenTypeOperator && previousToken.type == EquationTokenTypeOperator)
    {
      return [self produceError:error withCode:101 andMessage:@"Consecutive operators are not allowed"];
    }
    previousToken = token;
  }
  return YES;
}

- (BOOL)produceError:(NSError**)error withCode:(NSInteger)code andMessage:(NSString*)message 
{
  if (error != NULL) 
  {
    NSMutableDictionary *errorDetail = [NSMutableDictionary dictionary];
    [errorDetail setValue:message forKey:NSLocalizedDescriptionKey];
    *error = [NSError errorWithDomain:@"Graphique" code:code userInfo:errorDetail];
  }
  return NO;
}

- (void)tokenize
{
  [tokens removeAllObjects];
  Stack *stack = [[Stack alloc] init];
  
  NSString *temp = @"";
  EquationToken *token = nil;
  for (NSUInteger i = 0, n = text.length; i < n; i++) 
  {
    unichar c = [text characterAtIndex:i];
    temp = [temp stringByAppendingFormat:@"%C", c];
    
    // Keep all digits of a number as one token
    if (isdigit(c) || c == '.') 
    {
      // Keep reading characters until we hit the end of the string
      while (i < (n - 1)) 
      {
        // Increment our loop variable
        ++i;
        // Get the next character
        c = [text characterAtIndex:i];
        // Test to see whether to continue
        if (isdigit(c) || c == '.') 
        {
          // Append the character to the temp string
          temp = [temp stringByAppendingFormat:@"%C", c];
        } 
        else 
        {
          // Character didn't match, so back the loop counter up and exit
          --i;
          break;
        }
      }
    }
    
    // Keep all spaces together
    else if (c == ' ') 
    {
      // Keep reading characters until we hit the end of the string
      while (i < (n - 1)) 
      {
        // Increment our loop variable
        ++i;
        // Get the next character
        c = [text characterAtIndex:i];
        // Test to see whether to continue
        if (c == ' ') 
        {
          // Append the character to the temp string
          temp = [temp stringByAppendingFormat:@"%C", c];
        } 
        else 
        {
          // Character didn't match, so back the loop counter up and exit
          --i;
          break;
        }
      }
    }
    // Check for trig functions
    for (NSString *trig in TRIG_FUNCTIONS) 
    {
      if ([trig length] <= (n - i) && [trig isEqualToString:[[text substringWithRange:NSMakeRange(i, [trig length])] lowercaseString]]) 
      {
        temp = trig;
        i += ([trig length] - 1);
        break;
      }
    }
    
    // Check for symbols
    for (NSString *symbol in SYMBOLS) 
    {
      if ([symbol length] <= (n - i) && [symbol isEqualToString:[[text substringWithRange:NSMakeRange(i, [symbol length])] lowercaseString]]) 
      {
        temp = symbol;
        i += ([symbol length] - 1);
        break;
      }
    }

    token = [self newTokenFromString:temp];
    
    // Determine if this should be an exponent
    // Check that we have a previous token to follow and that this is a number
    if (token.type == EquationTokenTypeNumber && ![tokens count] == 0)
    {
      // Get the previous token
      EquationToken *previousToken = [tokens lastObject];
      
      // If the previous token is a variable, close parenthesis, or the ^ operator, this is an exponent
      if (previousToken.type == EquationTokenTypeVariable ||
          previousToken.type == EquationTokenTypeCloseParen ||
          [previousToken.value isEqualToString:@"^"])
      {
        token.type = EquationTokenTypeExponent;
      }
    }
    
    // Do parenthesis matching
    if (token.type == EquationTokenTypeOpenParen)
    {
      // Set the new open parenthesis to invalid, as it's not yet matched,
      // and push it onto the stack
      token.valid = NO;
      [stack push:token];
    }
    else if (token.type == EquationTokenTypeCloseParen)
    {
      // See if we have a matching open parenthesis
      if (![stack hasObjects])
      {
        // No open parenthesis to match, so this close parenthesis is invalid
        token.valid = NO;
      }
      else
      {
        // We have a matching open parenthesis, so set it (and this close parenthesis)
        // to valid and pop the open parenthesis off the stack
        EquationToken *match = [stack pop];
        match.valid = YES;
      }
    }
    
    // Numbers with more than one decimal point are invalid
    if (token.type == EquationTokenTypeNumber && [[token.value componentsSeparatedByString:@"."] count] > 2) 
    {
      token.valid = NO;
    }

    [tokens addObject:token];
    temp = @"";
  }
}

- (EquationToken *)newTokenFromString:(NSString *)string
{
  EquationTokenType type;
  string = [string lowercaseString];
  if ([OPERATORS containsObject:string])
  {
    type = EquationTokenTypeOperator;
  }
  else if ([TRIG_FUNCTIONS containsObject:string])
  {
    type = EquationTokenTypeTrigFunction;
  }
  else if ([SYMBOLS containsObject:string])
  {
    type = EquationTokenTypeSymbol;
  }
  else if ([string isEqualToString:@"("])
  {
    type = EquationTokenTypeOpenParen;
  }
  else if ([string isEqualToString:@")"])
  {
    type = EquationTokenTypeCloseParen;
  }
  else if ([string isEqualToString:@"x"])
  {
    type = EquationTokenTypeVariable;
  }
  // Digits are all grouped together in the tokenize: method, so just check the first character
  else if (isdigit([string characterAtIndex:0]) || [string characterAtIndex:0] == '.')
  {
    type = EquationTokenTypeNumber;
  }
  // Spaces are all grouped together in the tokenize: method, so just check the first character
  else if ([string characterAtIndex:0] == ' ')
  {
    type = EquationTokenTypeWhitespace;
  }
  else
  {
    type = EquationTokenTypeInvalid;
  }
  return [[EquationToken alloc] initWithType:type andValue:string];
}

- (NSString *)expand
{
  NSMutableString *expanded = [NSMutableString string];
  
  EquationToken *previousToken = nil;
  for (EquationToken *token in self.tokens)
  {
    // Get the value of the current token
    NSString *value = token.value;
    
    if (previousToken != nil)
    {
      // Do implicit exponents
      if (token.type == EquationTokenTypeExponent && ![previousToken.value isEqualToString:@"^"])
      {
        [expanded appendString:@"^"];
      }
      
      // Do implicit multiplication when token is an open parenthesis
      if (token.type == EquationTokenTypeOpenParen && (previousToken.type == EquationTokenTypeVariable || previousToken.type == EquationTokenTypeNumber))
      {
        [expanded appendString:@"*"];
      }
      
      // Do implicit multiplication when token is a variable or symbol
      if ((token.type == EquationTokenTypeVariable || token.type == EquationTokenTypeSymbol) && previousToken.type == EquationTokenTypeNumber)
      {
        [expanded appendString:@"*"];
      }
    }
    
    // Convert pi
    if ([value isEqualToString:@"pi"] || [value isEqualToString:@"\u03c0"])
    {
      value = [NSString stringWithFormat:@"%f", M_PI];
    }
    
    // Convert e
    if ([value isEqualToString:@"e"])
    {
      value = [NSString stringWithFormat:@"%f", M_E];
    }
    
    // Append the current token's value, which we may have adjusted
    [expanded appendString:value];
    
    // Keep a pointer to the previous token
    previousToken = token;
  }
  return expanded;
}

@end
