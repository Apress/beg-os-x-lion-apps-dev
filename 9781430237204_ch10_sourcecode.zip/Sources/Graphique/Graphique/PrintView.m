//
// From the book Beginning Mac OS X Lion Apps Development
// Michael Privat and Rob Warner
// Published by Apress, 2011
// Source released under the Eclipse Public License
// http://www.eclipse.org/legal/epl-v10.html
// 
// Contact information:
// Michael: @michaelprivat -- http://michaelprivat.com -- mprivat@mac.com
// Rob: @hoop33 -- http://grailbox.com -- rwarner@grailbox.com
//

#import "PrintView.h"
#import "GraphTableViewController.h"
#import "GraphView.h"

@implementation PrintView

@synthesize controller;

- (id)initWithFrame:(NSRect)frame
{
  self = [super initWithFrame:frame];
  if (self) {
    // Set up the font
    font = [NSFont fontWithName:@"Helvetica" size:12.0];
    
    // The height of a line is the height of the font
    // plus some proportional spacing so the lines
    // are not stuck together.
    heightPerLine = [font capHeight] * 1.5;
  }
  return self;
}

- (void)drawRect:(NSRect)dirtyRect
{
  NSPrintOperation *op = [NSPrintOperation currentOperation];
  NSRect pageBounds = op.printInfo.imageablePageBounds ;
  
  if (op.currentPage == 1) 
  {
    // First page, print the graph    
    GraphView *graph = [[GraphView alloc] initWithFrame: pageBounds];
    graph.controller = self.controller;
    [graph drawRect: dirtyRect];
  }
  else 
  {
    NSUInteger linesPerPage = pageBounds.size.height / heightPerLine;  
    
    // The print operation pages are 1-based. So we remove one to make it
    // zero-based and remove one to make room for the first page (the graph)
    long dataPage = op.currentPage - 2;
    
    NSDictionary *attributes = [NSDictionary dictionaryWithObject:font forKey:NSFontAttributeName];
    
    for (int i = 0; i < linesPerPage; i++) 
    {
      NSUInteger index = dataPage * linesPerPage + i;
      if (index >= controller.values.count ) break;
      
      NSValue *value = [controller.values objectAtIndex:index];
      NSPoint point = value.pointValue ;
      
      NSRect xRect = NSMakeRect(pageBounds.origin.x, op.currentPage * pageBounds.size.height - (i+1) * heightPerLine, 100, heightPerLine);
      [[NSString stringWithFormat:@"%.2f", point.x] drawInRect:xRect withAttributes:attributes]; 
      
      NSRect yRect = NSMakeRect(pageBounds.origin.x + 100, op.currentPage * pageBounds.size.height - (i+1) * heightPerLine, 100, heightPerLine);
      [[NSString stringWithFormat: @"%.2f", point.y] drawInRect: yRect withAttributes:attributes];
    }
  }
}

- (BOOL)knowsPageRange:(NSRangePointer)range
{
  NSPrintOperation *op = [NSPrintOperation currentOperation];
  NSPrintInfo *pInfo = op.printInfo;
  NSRect bounds = pInfo.imageablePageBounds;
  
  NSUInteger linesPerPage = bounds.size.height / heightPerLine;
  NSUInteger totalPages = 1 + controller.values.count / linesPerPage;
  
  totalPages++; // Count a page for the graph itself
  
  [self setFrame:NSMakeRect(0, 0, bounds.size.width, bounds.size.height * totalPages)];
  
  range->location = 1;
  range->length = totalPages;
  return YES;
}

- (NSRect)rectForPage:(int)page
{
  NSPrintOperation *op = [NSPrintOperation currentOperation];
  NSPrintInfo *pInfo = op.printInfo;
  NSRect bounds = pInfo.imageablePageBounds;
  
  return NSMakeRect(0, bounds.size.height * (page-1), bounds.size.width, bounds.size.height);
}

@end
