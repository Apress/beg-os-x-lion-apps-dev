//
// From the book Beginning Mac OS X Lion Apps Development
// Michael Privat and Rob Warner
// Published by Apress, 2011
// Source released under the Eclipse Public License
// http://www.eclipse.org/legal/epl-v10.html
// 
// Contact information:
// Michael: @michaelprivat -- http://michaelprivat.com -- mprivat@mac.com
// Rob: @hoop33 -- http://grailbox.com -- rwarner@grailbox.com
//
#include <CoreFoundation/CoreFoundation.h>
#include <CoreServices/CoreServices.h>
#include <QuickLook/QuickLook.h>

#import <Cocoa/Cocoa.h>

OSStatus GenerateThumbnailForURL(void *thisInterface, QLThumbnailRequestRef thumbnail, CFURLRef url, CFStringRef contentTypeUTI, CFDictionaryRef options, CGSize maxSize);
void CancelThumbnailGeneration(void *thisInterface, QLThumbnailRequestRef thumbnail);

/* -----------------------------------------------------------------------------
 Generate a thumbnail for file
 
 This function's job is to create thumbnail for designated file as fast as possible
 ----------------------------------------------------------------------------- */

OSStatus GenerateThumbnailForURL(void *thisInterface, QLThumbnailRequestRef thumbnail, CFURLRef url, CFStringRef contentTypeUTI, CFDictionaryRef options, CGSize maxSize)
{
  NSRect canvas = {0, 0, 100, 100};
  CGContextRef cgContext = QLThumbnailRequestCreateContext(thumbnail, *(CGSize *)&(canvas.size), false, NULL);
  if(cgContext) {
    NSGraphicsContext* context = [NSGraphicsContext graphicsContextWithGraphicsPort:(void *)cgContext flipped:YES];
    if(context) {
      [NSGraphicsContext saveGraphicsState];
			[NSGraphicsContext setCurrentContext:context];
      
      NSDictionary *data = [[NSDictionary alloc] initWithContentsOfURL:(__bridge  NSURL*)url];  
      NSData *imgData = [data objectForKey:@"image"];
      NSImage *image = [[NSImage alloc] initWithData:imgData];
      [image drawInRect:canvas fromRect:NSZeroRect operation:NSCompositeSourceOver fraction:1.0];
      
      [NSGraphicsContext restoreGraphicsState];
    }
    QLThumbnailRequestFlushContext(thumbnail, cgContext);
    CFRelease(cgContext);
  }
  
  return noErr;
}

void CancelThumbnailGeneration(void *thisInterface, QLThumbnailRequestRef thumbnail)
{
  // Implement only if supported
}
