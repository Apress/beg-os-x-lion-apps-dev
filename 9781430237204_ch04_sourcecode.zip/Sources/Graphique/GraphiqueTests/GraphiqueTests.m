//
// From the book Beginning Mac OS X Lion Apps Development
// Michael Privat and Rob Warner
// Published by Apress, 2011
// Source released under the Eclipse Public License
// http://www.eclipse.org/legal/epl-v10.html
// 
// Contact information:
// Michael: @michaelprivat -- http://michaelprivat.com -- mprivat@mac.com
// Rob: @hoop33 -- http://grailbox.com -- rwarner@grailbox.com
//

#import "GraphiqueTests.h"
#import "Equation.h"

@implementation GraphiqueTests

- (void)setUp
{
  [super setUp];
}

- (void)tearDown
{
  [super tearDown];
}

- (void)testEquationValidation 
{
  NSError *error = nil;
  Equation *equation = [[Equation alloc] initWithString:@"( 3+4*7 /(3+ 4))"];
  if(![equation validate:&error]) 
  {
    STFail(@"Equation should have been valid");
  }
}

- (void)testEquationValidationWithInvalidCharacters 
{
  NSError *error = nil;
  Equation *equation = [[Equation alloc] initWithString:@"invalid characters"];
  if([equation validate:&error]) 
  {
    STFail(@"Equation should not have been valid");
  }
  
  if([error code] != 100) 
  {
    STFail(@"Validation should have failed with code 100 instead of %d", [error code]);
  }
}

- (void)testEquationValidationWithConsecutiveOperators 
{
  NSError *error = nil;
  Equation *equation = [[Equation alloc] initWithString:@"2++3"];
  if([equation validate:&error]) 
  {
    STFail(@"Equation should not have been valid");
  }
  
  if([error code] != 101) 
  {
    STFail(@"Validation should have failed with code 101 instead of %d", [error code]);
  }
}

- (void)testEquationValidationWithTooManyOpenBrackets 
{
  NSError *error = nil;
  Equation *equation = [[Equation alloc] initWithString:@"((4+3)"];
  if([equation validate:&error]) 
  {
    STFail(@"Equation should not have been valid");
  }
  
  if([error code] != 102) 
  {
    STFail(@"Validation should have failed with code 102 instead of %d", [error code]);
  }
}

- (void)testEquationValidationWithTooManyCloseBrackets 
{
  NSError *error = nil;
  Equation *equation = [[Equation alloc] initWithString:@"(4+3))"];
  if([equation validate:&error]) 
  {
    STFail(@"Equation should not have been valid");
  }
  
  if([error code] != 103) 
  {
    STFail(@"Validation should have failed with code 103 instead of %d", [error code]);
  }
}

@end
