//
// From the book Beginning Mac OS X Lion Apps Development
// Michael Privat and Rob Warner
// Published by Apress, 2011
// Source released under the Eclipse Public License
// http://www.eclipse.org/legal/epl-v10.html
// 
// Contact information:
// Michael: @michaelprivat -- http://michaelprivat.com -- mprivat@mac.com
// Rob: @hoop33 -- http://grailbox.com -- rwarner@grailbox.com
//

#import "EquationEntryViewController.h"
#import "GraphiqueAppDelegate.h"
#import "Equation.h"
#import "GraphTableViewController.h"
#import "EquationToken.h"

@implementation EquationEntryViewController

@synthesize textField;
@synthesize feedback;

static NSDictionary *COLORS;

+ (void)initialize
{
  COLORS = [NSDictionary dictionaryWithObjectsAndKeys:
            [NSColor whiteColor],   [NSNumber numberWithInt:EquationTokenTypeInvalid],
            [NSColor blackColor],   [NSNumber numberWithInt:EquationTokenTypeNumber],
            [NSColor blueColor],    [NSNumber numberWithInt:EquationTokenTypeVariable],
            [NSColor brownColor],   [NSNumber numberWithInt:EquationTokenTypeOperator],
            [NSColor purpleColor],  [NSNumber numberWithInt:EquationTokenTypeOpenParen],
            [NSColor purpleColor],  [NSNumber numberWithInt:EquationTokenTypeCloseParen],
            [NSColor orangeColor],  [NSNumber numberWithInt:EquationTokenTypeExponent],
            [NSColor cyanColor],    [NSNumber numberWithInt:EquationTokenTypeSymbol],
            [NSColor magentaColor], [NSNumber numberWithInt:EquationTokenTypeTrigFunction],
            [NSColor whiteColor],   [NSNumber numberWithInt:EquationTokenTypeWhitespace],
            nil];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
  self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
  if (self) {
    // Initialization code here.
  }
  
  return self;
}

- (void)alertDidEnd:(NSAlert *)alert returnCode:(NSInteger)returnCode
        contextInfo:(void *)contextInfo 
{
  
}

- (IBAction)equationEntered:(id)sender
{
  GraphiqueAppDelegate *delegate = NSApplication.sharedApplication.delegate;
  
  Equation *equation = [[Equation alloc] initWithString:[self.textField stringValue]];
  NSError *error = nil;
  if(![equation validate:&error]) 
  {
    // Validation failed, display the error
    NSAlert *alert = [[NSAlert alloc] init];
    [alert addButtonWithTitle:@"OK"];
    [alert setMessageText:@"Something went wrong. "];
    [alert setInformativeText:[NSString stringWithFormat:@"Error %d: %@", [error code],[error localizedDescription]]];
    [alert setAlertStyle:NSWarningAlertStyle];
    
    [alert beginSheetModalForWindow:delegate.window modalDelegate:self didEndSelector:@selector(alertDidEnd:returnCode:contextInfo:) contextInfo:nil];
  }
  else 
  {
    [delegate.graphTableViewController draw:equation];
  }
}

- (void)controlTextDidChange:(NSNotification *)notification 
{
  Equation *equation = [[Equation alloc] initWithString: [self.textField stringValue]];
  
  // Create a mutable attributed string, initialized with the contents of the equation text field
  NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:[self.textField stringValue]];
  
  // Variable to keep track of where we are in the attributed string
  int i = 0;
  
  // Loop through the tokens
  for (EquationToken *token in equation.tokens)
  {
    // The range makes any attributes we add apply to the current token only
    NSRange range = NSMakeRange(i, [token.value length]);
    
    // Add the foreground color
    [attributedString addAttribute:NSForegroundColorAttributeName value:[COLORS objectForKey:[NSNumber numberWithInt:token.type]] range:range];
    
    // Add the background color
    [attributedString addAttribute:NSBackgroundColorAttributeName value:token.valid ? [NSColor whiteColor] : [NSColor redColor] range:range];
    
    // If token is an exponent, make it superscript
    if (token.type == EquationTokenTypeExponent)
    {
      // Get the height of the rest of the text
      CGFloat height = [[textField font] pointSize] * 0.5;
      
      // Set the exponent font height
      [attributedString addAttribute:NSFontAttributeName value:[NSFont systemFontOfSize:height] range:range];
      
      // Shift the exponent upwards
      [attributedString addAttribute:NSBaselineOffsetAttributeName value:[NSNumber numberWithInt:height] range:range];
    }

    // Advance the index to the next token
    i += [token.value length];
  }
  // Set the attributed string back into the equation entry field
  [self.textField setAttributedStringValue:attributedString];
  
  NSError *error = nil;
  if(![equation validate:&error]) 
  {
    // Validation failed, display the error
    [feedback setStringValue:[NSString stringWithFormat:@"Error %d: %@", [error code],[error localizedDescription]]];
  }
  else 
  {
    [feedback setStringValue:@""];
  }
}

@end
