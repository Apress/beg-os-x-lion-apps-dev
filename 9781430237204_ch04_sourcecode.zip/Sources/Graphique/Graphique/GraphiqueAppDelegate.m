//
// From the book Beginning Mac OS X Lion Apps Development
// Michael Privat and Rob Warner
// Published by Apress, 2011
// Source released under the Eclipse Public License
// http://www.eclipse.org/legal/epl-v10.html
// 
// Contact information:
// Michael: @michaelprivat -- http://michaelprivat.com -- mprivat@mac.com
// Rob: @hoop33 -- http://grailbox.com -- rwarner@grailbox.com
//


#import "GraphiqueAppDelegate.h"
#import "EquationEntryViewController.h"
#import "GraphTableViewController.h"
#import "RecentlyUsedEquationsViewController.h"

@implementation GraphiqueAppDelegate

@synthesize window = _window;
@synthesize horizontalSplitView;
@synthesize verticalSplitView;
@synthesize equationEntryViewController;
@synthesize graphTableViewController;
@synthesize recentlyUsedEquationsViewController;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
  self.equationEntryViewController = [[EquationEntryViewController alloc] initWithNibName:@"EquationEntryViewController" bundle:nil];
  [self.verticalSplitView replaceSubview:[[self.verticalSplitView subviews] objectAtIndex:1] with:equationEntryViewController.view];
  
  self.graphTableViewController = [[GraphTableViewController alloc] initWithNibName:@"GraphTableViewController" bundle:nil];
  [self.horizontalSplitView replaceSubview:[[self.horizontalSplitView subviews] objectAtIndex:1] with:graphTableViewController.view];
  
  self.recentlyUsedEquationsViewController = [[RecentlyUsedEquationsViewController alloc] initWithNibName:@"RecentlyUsedEquationsViewController" bundle:nil];
  [self.verticalSplitView replaceSubview:[[self.verticalSplitView subviews] objectAtIndex:0] with:recentlyUsedEquationsViewController.view];
  self.verticalSplitView.delegate = recentlyUsedEquationsViewController;
}

- (void)applicationDidBecomeActive:(NSNotification *)aNotification 
{
}

- (void)applicationDidResignActive:(NSNotification *)aNotification
{
}

@end
