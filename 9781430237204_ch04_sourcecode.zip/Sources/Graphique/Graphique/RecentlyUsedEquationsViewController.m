//
// From the book Beginning Mac OS X Lion Apps Development
// Michael Privat and Rob Warner
// Published by Apress, 2011
// Source released under the Eclipse Public License
// http://www.eclipse.org/legal/epl-v10.html
// 
// Contact information:
// Michael: @michaelprivat -- http://michaelprivat.com -- mprivat@mac.com
// Rob: @hoop33 -- http://grailbox.com -- rwarner@grailbox.com
//

#import "RecentlyUsedEquationsViewController.h"
#import "GroupItem.h"
#import "EquationItem.h"

#define EQUATION_ENTRY_MIN_WIDTH 175.0
#define PREFERRED_RECENT_EQUATIONS_MIN_WIDTH 100.0

@implementation RecentlyUsedEquationsViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil 
{
  self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
  if (self) 
  {
    rootItem = [[GroupItem alloc] init];
    
    for (int i = 0; i < 4; i++) 
    {
      GroupItem *temp = [[GroupItem alloc] init];
      temp.name = [NSString stringWithFormat:@"Group %d", i + 1];
      
      for (int j = 0; j < 5; j++) 
      {
        EquationItem *item = [[EquationItem alloc] init];
        [temp addChild:item];
      }
      [rootItem addChild:temp];
    }
  }  
  return self;
}

- (NSInteger)outlineView:(NSOutlineView *)outlineView numberOfChildrenOfItem:(id)item 
{
  return (item == nil) ? [rootItem numberOfChildren] : [item numberOfChildren];
}

- (BOOL)outlineView:(NSOutlineView *)outlineView isItemExpandable:(id)item 
{
  return (item == nil) ? ([rootItem numberOfChildren] > 0) : ([item numberOfChildren] > 0);
}

- (id)outlineView:(NSOutlineView *)outlineView child:(NSInteger)index ofItem:(id)item 
{
  if (item == nil) 
  {
    return [rootItem childAtIndex:index];
  } 
  else 
  {
    return [(GroupItem *)item childAtIndex:index];
  }
}

- (id)outlineView:(NSOutlineView *)outlineView objectValueForTableColumn:(NSTableColumn *)tableColumn byItem:(id)item 
{
  return (item == nil) ? @"" : [item text];
}

# pragma mark - NSSplitViewDelegate methods

- (CGFloat)splitView:(NSSplitView *)splitView constrainMaxCoordinate:(CGFloat)proposedMinimumPosition ofSubviewAt:(NSInteger)dividerIndex 
{
  return splitView.frame.size.width - EQUATION_ENTRY_MIN_WIDTH; 
}

- (void)splitView:(NSSplitView *)splitView resizeSubviewsWithOldSize:(NSSize)oldSize 
{
  // Get the new frame of the split view
  NSSize size = splitView.bounds.size;
  
  // Get the divider width
  CGFloat dividerWidth = splitView.dividerThickness;
  
  // Get the frames of the recently used equations panel and the equation entry panel
  NSArray *views = splitView.subviews;
  NSRect recentlyUsed = [[views objectAtIndex:0] frame];
  NSRect equationEntry = [[views objectAtIndex:1] frame];
  
  // Set the widths
  // Sizing strategy:
  // 1) equation entry must be a minimum of 175 pixels minus the divider width
  // 2) recently used will stay at its current size, unless it's less than 100 pixels wide
  // 3) If recently used is less than 100 pixels, grow it as much as possible until it reaches 100
  float totalFrameWidth = size.width - dividerWidth;
  
  // Set recently used to the desired size (at least 100 pixels wide), or keep at zero
  // if it was collapsed
  recentlyUsed.size.width = recentlyUsed.size.width == 0 ? 0 : MAX(PREFERRED_RECENT_EQUATIONS_MIN_WIDTH, recentlyUsed.size.width);
  
  // Calculate the size of the equation entry based on the recently used width
  equationEntry.size.width = MAX((EQUATION_ENTRY_MIN_WIDTH - dividerWidth), (totalFrameWidth - recentlyUsed.size.width));
  
  // Now that the equation entry is set, recalculate the recently used
  recentlyUsed.size.width = totalFrameWidth - equationEntry.size.width;
  
  // Set the x location of the equation entry
  equationEntry.origin.x = recentlyUsed.size.width + dividerWidth;
  
  // Set the widths
  [[views objectAtIndex:0] setFrame:recentlyUsed];
  [[views objectAtIndex:1] setFrame:equationEntry];
}

- (BOOL)splitView:(NSSplitView *)splitView shouldCollapseSubview:(NSView *)subview forDoubleClickOnDividerAtIndex:(NSInteger)dividerIndex 
{
  return subview == self.view;
}

- (BOOL)splitView:(NSSplitView *)splitView canCollapseSubview:(NSView *)subview 
{
  return subview == self.view;
}

@end
