//
// From the book Beginning Mac OS X Lion Apps Development
// Michael Privat and Rob Warner
// Published by Apress, 2011
// Source released under the Eclipse Public License
// http://www.eclipse.org/legal/epl-v10.html
// 
// Contact information:
// Michael: @michaelprivat -- http://michaelprivat.com -- mprivat@mac.com
// Rob: @hoop33 -- http://grailbox.com -- rwarner@grailbox.com
//

#import "GraphTableViewController.h"
#import "GraphView.h"

@implementation GraphTableViewController

@synthesize values;
@synthesize graphTableView;
@synthesize interval;
@synthesize graphView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
  self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
  if (self) {
    self.values = [NSMutableArray array];
    self.interval = 1.0;
  }
  
  return self;
}

- (void)draw:(Equation *)equation 
{
  // Clear the cache
  [values removeAllObjects];
  
  // Calculate the values
  for (float x = -50.0; x <= 50.0; x += interval) 
  {
    float y = [equation evaluateForX:x];
    [values addObject:[NSValue valueWithPoint:CGPointMake(x, y)]];
  }
  [self.graphTableView reloadData];
  
  [self.graphView setNeedsDisplay:YES];
}

#pragma mark - NSTableViewDatasource methods

- (NSInteger)numberOfRowsInTableView:(NSTableView *)tableView 
{
  return values.count;
}

- (id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex 
{
  CGPoint point = [[values objectAtIndex:rowIndex] pointValue];
  float value = [[aTableColumn identifier] isEqualToString:@"X"] ? point.x : point.y;
  return [NSString stringWithFormat:@"%0.2f", value];
}

@end
