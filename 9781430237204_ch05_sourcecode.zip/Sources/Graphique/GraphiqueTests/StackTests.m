//
// From the book Beginning Mac OS X Lion Apps Development
// Michael Privat and Rob Warner
// Published by Apress, 2011
// Source released under the Eclipse Public License
// http://www.eclipse.org/legal/epl-v10.html
// 
// Contact information:
// Michael: @michaelprivat -- http://michaelprivat.com -- mprivat@mac.com
// Rob: @hoop33 -- http://grailbox.com -- rwarner@grailbox.com
//

#import "StackTests.h"
#import "Stack.h"

@implementation StackTests

- (void)testPushAndPop
{
  Stack *stack = [[Stack alloc] init];
  for (int i = 0; i < 1000; i++)
  {
    [stack push:[NSString stringWithFormat:@"String #%d", i]];
  }
  STAssertTrue([stack hasObjects], @"Stack should not be empty after pushing 1,000 objects");
  
  for (int i = 999; i >= 0; i--)
  {
    NSString *string = (NSString *)[stack pop];
    NSString *comp = [NSString stringWithFormat:@"String #%d", i];
    STAssertEqualObjects(string, comp, NULL);
  }
  STAssertFalse([stack hasObjects], @"Stack should be empty after popping 1,000 objects");
}

@end
